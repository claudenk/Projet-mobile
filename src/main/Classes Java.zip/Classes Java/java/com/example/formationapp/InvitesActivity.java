package com.example.formationapp;

import static com.example.formationapp.R.*;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

 import android.os.Bundle;
        import android.widget.TextView;

        import androidx.appcompat.app.AppCompatActivity;

        import java.util.List;

        import entity.Invites;
        import dao.InvitesDao;

public class InvitesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invites);

        // Récupérer les TextViews depuis le layout XML
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        TextView idTextView = findViewById(R.id.idTextView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        TextView invitesTextView = findViewById(R.id.invitesTextView);

        // Charger les données des invités depuis la base de données
        List<Invites> invitesList = InvitesDao.findAllInvites();

        // Afficher les données dans les TextViews
        StringBuilder idText = new StringBuilder();
        StringBuilder invitesText = new StringBuilder();
        for (Invites invites : invitesList) {
            idText.append(invites.getId()).append("\n");
            // Ajouter le code pour récupérer et afficher les autres informations des invités
            // Par exemple, si vous souhaitez afficher le nom et l'email des invités :
            // Invites invites = InvitesDao.findInvitesById(invites.getId());
            // String name = invites.getName();
            // String email = invites.getEmail();
            // invitesText.append("Nom : ").append(name).append(", Email : ").append(email).append("\n");
        }

        idTextView.setText(idText.toString());
        invitesTextView.setText(invitesText.toString());
    }
}