package com.example.formationapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.time.LocalDate;

import dao.DejeunerDao;
import entity.Dejeuner;

public class DejeunerActivity extends AppCompatActivity {

    private EditText editTextType;
    private EditText editTextNomSociete;
    private Button buttonSave;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dejeuner);

        // Trouver les éléments de l'interface utilisateur
        editTextType = findViewById(R.id.editTextType);
        editTextNomSociete = findViewById(R.id.editTextNomSociete);
        buttonSave = findViewById(R.id.buttonSave);

        // Ajouter un écouteur d'événements au bouton de sauvegarde
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupérer les valeurs des champs
                String type = editTextType.getText().toString();
                String nomSociete = editTextNomSociete.getText().toString();

                // Créer un objet Dejeuner avec les valeurs entrées par l'utilisateur
                LocalDate date = null;
                Dejeuner dejeuner = new Dejeuner();

                // Appeler la méthode pour sauvegarder le Dejeuner dans la base de données
                saveDejeuner(dejeuner);
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void saveDejeuner(Dejeuner dejeuner) {
        // Appeler la méthode dans DejeunerDao pour sauvegarder le Dejeuner
        DejeunerDao.saveDejeuner(dejeuner);

        // Afficher un message de succès à l'utilisateur
        Toast.makeText(this, "Dejeuner enregistré avec succès", Toast.LENGTH_SHORT).show();

        // Réinitialiser les champs après la sauvegarde
        editTextType.setText("type");
        editTextNomSociete.setText("NomSociete");
    }
}