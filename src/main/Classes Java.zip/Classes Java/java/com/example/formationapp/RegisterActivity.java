package com.example.formationapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import dao.RoleDao;
import dao.UserDao;
import entity.User;


public class RegisterActivity extends AppCompatActivity {
    private EditText editTextEmail, editTextPassword, editTextNom, editTextPrenom;
    public Button buttonRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextNom = findViewById(R.id.editTextNom);
        editTextPrenom = findViewById(R.id.editTextPrenom);
        buttonRegister = findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void registerUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String nom = editTextNom.getText().toString().trim();
        String prenom = editTextPrenom.getText().toString().trim();

        // Validation des champs (a implémenter)

        User newUser = new User();
        newUser.setemail(email);
        newUser.setpassword(password); // Pensez à hasher le mot de passe pour la sécurité
        newUser.setnom(nom);
        newUser.setprenom(prenom);

        UserDao.saveUser(newUser);

        newUser.setrole(RoleDao.findRoleById(1));



// Affichage d'un message de succès
        Toast.makeText(this, "Utilisateur enregistré avec succès",
                Toast.LENGTH_SHORT).show();

// Redirection vers MainActivity
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Termine RegisterActivity pour empêcher l'utilisateur de revenir à cette activité en appuyant sur le bouton retour

    }


}

