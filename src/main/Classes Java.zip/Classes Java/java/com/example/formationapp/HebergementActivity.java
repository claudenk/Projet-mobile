package com.example.formationapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.TextView;

import dao.HebergementDao;
import entity.Hebergement;

public class HebergementActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hebergement);




                // Récupérer l'ID de l'hébergement à afficher depuis l'intent
                int hebergementId = getIntent().getIntExtra("hebergementId", -1);

                // Récupérer les détails de l'hébergement depuis la base de données
        HebergementDao HebergementDao = new HebergementDao(userDao);
        Hebergement hebergement = HebergementDao.findHebergementById(hebergementId);

                // Afficher les détails de l'hébergement dans l'interface utilisateur
                if (hebergement != null) {
                    TextView dateTextView = findViewById(R.id.dateTextView);
                    dateTextView.setText("Date: " + hebergement.getDate());

                    TextView montantTextView = findViewById(R.id.montantTextView);
                    montantTextView.setText("Montant: " + hebergement.getMontant());

                    TextView distanceTextView = findViewById(R.id.distanceTextView);
                    distanceTextView.setText("Distance: " + hebergement.getDistance());

                    TextView typeTextView = findViewById(R.id.typeTextView);
                    typeTextView.setText("Type: " + hebergement.getType().toString());

                    TextView userTextView = findViewById(R.id.userTextView);
                    userTextView.setText("Utilisateur: " + hebergement.getUser().getNom() + " " + hebergement.getUser().getPrenom());
                }
            }
        }


