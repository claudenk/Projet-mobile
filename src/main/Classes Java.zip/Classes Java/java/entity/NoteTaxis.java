package entity;

import androidx.annotation.NonNull;

import java.time.LocalDate;
public class NoteTaxis extends NoteDeFrais {

    private String villeDepart;
    private String villeArrivee;
    private String nomClient;
    private Type type;
    private User user;

    public NoteTaxis(LocalDate date, double montant, String villeDepart, String villeArrivee, String nomClient, Type type, entity.User user) {
        super();
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.nomClient = nomClient;
        this.type = type;
        this.user = user;
    }

    public NoteTaxis() {

    }

    public String getVilleDepart() {
        return villeDepart;
    }

    public void setVilleDepart(String villeDepart) {
        this.villeDepart = villeDepart;
    }

    public String getVilleArrivee() {
        return villeArrivee;
    }

    public void setVilleArrivee(String villeArrivee) {
        this.villeArrivee = villeArrivee;
    }

    public String getNomClient() {
        return nomClient;
    }

    public void setNomClient(String nomClient) {
        this.nomClient = nomClient;
    }

    @NonNull
    @Override
    public String toString() {

        String resultat = "" ;

        resultat += "\nVille de départ : " + villeDepart ;
        resultat += "\nVille d'arrivée : " + villeArrivee ;
        resultat += "\nNom du client : " + nomClient ;

        return resultat ;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public entity.User getUser() {
        return user;
    }

    @Override
    public void setUser(entity.User user) {
        this.user = user;
    }
}

