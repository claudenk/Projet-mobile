package entity;

import androidx.annotation.NonNull;

import java.time.LocalDate;

public class Hebergement extends NoteDeFrais {

   private LocalDate date;
    private int distance;
    private Type type;
    private User user;




    public Hebergement(LocalDate date, double montant, int distance, Type type, entity.User user) {
        super();
        this.distance = distance;
        this.type = type;
        this.user = user;
        this.date=date;
    }

    public Hebergement() {
        super();
    }


    // Getters et setters`
    public void setDistance(int distance) {
        this.distance = distance;
    }
    public int getDistance() {
        return distance;
    }

    @NonNull
    @Override
    public String toString() {

        String resultat = "" ;

        resultat += "\nVille : " + distance ;

        return resultat ;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public entity.User getUser() {
        return user;
    }

    @Override
    public void setUser(entity.User user) {
        this.user = user;
    }

    @Override
    public LocalDate getDate() {
        return date;
    }

    @Override
    public void setDate(LocalDate date) {
        this.date = date;
    }
}
