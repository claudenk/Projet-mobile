package entity;

import java.io.Serializable;

public class User implements Serializable {
    private int id;
    private String email;
    private String password;
    private String nom;
    private String prenom;
    private Role role;
    private NoteDeFrais noteDeFrais;



    //ajoutez les getters et les setters
public int getid() {
    return id;
}
    public void setId(int id) {
        this.id = id;
    }
    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email=email;
    }
    public String getpassword() {
        return password;
    }
    public void setpassword(String password) {
        this.password=password;
    }
    public String getnom() {
        return nom;
    }
    public void setnom(String nom) {
        this.nom=nom;
    }
    public String getprenom() {
        return prenom;
    }
    public void setprenom(String prenom) {
        this.prenom=prenom;
    }
    public Role geterole() {
        return role;
    }
    public void setrole(Role role) {
        this.role=role;
    }

    public String getNom() {
    return nom;
}

    public String getPrenom() {
    return prenom;
    }

    public String getId() {
    return id;
    }

    public String getEmail() {
    return email;
    }

    public NoteDeFrais getNoteDeFrais() {
        return noteDeFrais;
    }

    public void setNoteDeFrais(NoteDeFrais noteDeFrais) {
        this.noteDeFrais = noteDeFrais;
    }

    public Role getrole() {
    return role;
    }
}


