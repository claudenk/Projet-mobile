package entity;


import androidx.annotation.NonNull;

import java.time.LocalDate;

import java.util.List;
public class Dejeuner extends NoteDeFrais {

    private static double montant =1 ;
    private static Type type;
    private static User user;
    private static List<String> invites;
    private static String nomSociete;

    public Dejeuner(LocalDate date, double montant, Type type, User user, List<String> invites, String nomSociete) {
        super(); // Appel du constructeur de la classe parente
        this.montant = montant;
        this.type = type;
        this.user = user;
        this.invites = invites;
        this.nomSociete = nomSociete;
    }

    public Dejeuner() {
        super();
    }


    public static String getInvites() {return invites.toString();
    }

    public static byte[] getNomSociete() {return nomSociete.getBytes();
    }


    @NonNull
    @Override


	public String toString() {
	
		String resultat = "" ;
		
		resultat += "\nListe d'inviter : " + invites ;
		resultat += "\nNom de la société: " + nomSociete ;

		
		return resultat ;
	}


    public Type getType() {
        return type;
    }

    @Override
    public void setType(Type type) {
        this.type = type;
    }

    public entity.User getUser() {
        return user;
    }

    @Override
    public void setUser(entity.User user) {
        this.user = user;
    }

    public void setInvites(String invites) {
    }

    public void setNomSociete(String nomSociete) {
    }

    public void setType(String type) {
    }

    public void setUser(String user) {
    }
}
