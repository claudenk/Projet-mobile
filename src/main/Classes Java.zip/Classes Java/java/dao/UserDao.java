package dao;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;

import com.example.formationapp.MyApplication;

import java.util.ArrayList;
import java.util.List;

import entity.Dejeuner;
import entity.User;
import entity.Role;


public class UserDao {
    private static RoleDao roleDao;

    //Create
    public static void saveUser(User user) {
        SQLiteDatabase db = MyApplication.getDbHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", user.getemail());
        values.put("password", user.getpassword());
        values.put("nom", user.getnom());
        values.put("prenom", user.getprenom());
        values.put("roleId", user.getrole().getId());
        db.insert("User", null, values);
        db.close();
    }



    //read(Single User)
    @SuppressLint("Range")
    public static User findUserById(int userId) {
        SQLiteDatabase db = MyApplication.getDbHelper().getReadableDatabase();
        Cursor cursor = db.query("User", null, "id=?", new String[]{String.valueOf(userId)}, null, null, null);

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndex("id")));
            user.setemail(cursor.getString(cursor.getColumnIndex("email")));
            user.setpassword(cursor.getString(cursor.getColumnIndex("password")));
            user.setnom(cursor.getString(cursor.getColumnIndex("nom")));
            user.setprenom(cursor.getString(cursor.getColumnIndex("prenom")));
            int roleId = cursor.getInt(cursor.getColumnIndex("roleId"));
            Role role = RoleDao.findRoleById(roleId);
            user.setrole(role);
        }
        cursor.close();
        db.close();
        return user;
    }

   // Read (All Users)
    @NonNull
    @SuppressLint("Range")
    public static List<User> findAllUsers() {
        List<User> users = new ArrayList<>();
        SQLiteDatabase db = MyApplication.getDbHelper().getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM User", null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(cursor.getInt(cursor.getColumnIndex("id")));
                user.setemail(cursor.getString(cursor.getColumnIndex("email")));
                user.setpassword(cursor.getString(cursor.getColumnIndex("password")));
                user.setnom(cursor.getString(cursor.getColumnIndex("nom")));
                user.setprenom(cursor.getString(cursor.getColumnIndex("prenom")));

                int roleId = cursor.getInt(cursor.getColumnIndex("roleId"));
                Role role = RoleDao.findRoleById(roleId);
                user.setrole(role);

                users.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return users;
    }

    // Update
    public static int updateUser(User user) {
        SQLiteDatabase db = MyApplication.getDbHelper().getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", user.getemail());
        values.put("password", user.getpassword());
        values.put("nom", user.getnom());
        values.put("prenom", user.getprenom());
        values.put("roleId", user.geterole().getId());

        int rowsAffected = db.update("User", values, "id=?", new String[]{String.valueOf(user.getid())});
        db.close();
        return rowsAffected;
    }

    // Delete
    public static void deleteUser(int userId) {
        SQLiteDatabase db = MyApplication.getDbHelper().getWritableDatabase();
        db.delete("User", "id=?", new String[]{String.valueOf(userId)});
        db.close();
    }
@SuppressLint("Range")
public static User findUserByEmailAndPassword(String email, String password) {
    SQLiteDatabase db = MyApplication.getDbHelper().getReadableDatabase();

    String[] columns = new String[]{"id", "email", "password", "nom", "prenom", "roleId"};
    String selection = "email = ? AND password = ?";
    String[] selectionArgs = new String[]{email, password};

    Cursor cursor = db.query("User", columns, selection, selectionArgs, null, null, null);

    User user = null;
    if (cursor.moveToFirst()) {
        user = new User();
        user.setId(cursor.getInt(cursor.getColumnIndex("id")));
        user.setemail(cursor.getString(cursor.getColumnIndex("email")));
        user.setpassword(cursor.getString(cursor.getColumnIndex("password")));
        user.setnom(cursor.getString(cursor.getColumnIndex("nom")));
        user.setprenom(cursor.getString(cursor.getColumnIndex("prenom")));

        // Récupérer et associer le rôle de l'utilisateur
        int roleId = cursor.getInt(cursor.getColumnIndex("roleId"));
        Role role = RoleDao.findRoleById(roleId);
        user.setrole(role);
    }

    cursor.close();
    db.close();
    return user;
}

}







